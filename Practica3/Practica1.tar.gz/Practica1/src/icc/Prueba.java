package icc;

public class Prueba {

    public static void main(String[] args) {
        System.out.println("\t ***** P R A C T I C A   1 *****");
        System.out.println("\t Practica por: PEREZ SERVIN DARSHAN ISRAEL\n");

        /**
         * 1. Calcula el precio total resultante de la compra de tantos
         * artículos como indica numArticulos, cada uno con precio igual a
         * precioUnitario, declara una variable que almacene ese resultado e
         * imprime su valor en pantalla.
         */

        short numArticulos = 30;
        float precioUnitario = 15.42f;

        System.out.println("\t Numero de Articulos:\t\t" + numArticulos);
        System.out.println("\t Precio Unitario:\t\t" + precioUnitario);

        float TotalArticulos = numArticulos * precioUnitario; //Calcula el precio (SinIVA)
        
        System.out.println("\t Precio de los Articulos:\t" + TotalArticulos);

        /**
         * 2. Calcula el precio de todos los artículos con IVA incluido,
         * asignando el resultado a una variable e imprime su valor en pantalla.
         */

        final double IVA = 0.16;
        System.out.println("\t Porcentaje del IVA:\t\t" + IVA);
        
        double TotalArticulosIVA = TotalArticulos * IVA; //Calcula el IVA
        double TOTAL = TotalArticulosIVA + TotalArticulos; //Suma el IVA al precio de los articulos.
        System.out.println("\t\t\t\t\t-----------------");
        System.out.println("\t TOTAL (Con IVA incluido):\t"+ TOTAL);
        /**
         * 3. imprime en pantalla los valores de las variables caracter y valor.
         */

        char caracter = 'c';
        boolean valor = true;
        System.out.println("\t-------------------------------------------------");
        System.out.println("\t Caracter:\t"+caracter);
        System.out.println("\t Valor:\t\t"+valor);
        /**
         * Define constantes o variables para representar los siguientes datos,
         * trata de usar un tipo de datos adecuado  (suficiente para que se
         * pueda representar lo que se necesita).
         */
        System.out.println("\t-------------------------------------------------");
        // 4. El numero de lados de una figura geométrica.
        int LadosFiguraCUadrado = 4;
        System.out.println("\t 4. Lados de un cuadrado:\t"+ LadosFiguraCUadrado);

        // 5. ¿Eres menor de edad?
        boolean MayorMenordeEdad = true;
        System.out.println("\t 5. ¿Eres menor de edad?:\t" + MayorMenordeEdad);

        // 6. El número 34567.236789.
        double inciso6 = 34567.236789;
        System.out.println("\t 6. El número 34567.236789\t"+ inciso6);

        // 7. El símbolo $.
        String SimboloDinero = "$";
        System.out.println("\t 7. El símbolo $:\t\t"+ SimboloDinero);

        // 8. El número 14506783914
        long inciso8 = 14506783914L;
        System.out.println("\t 8. El número 14506783914:\t"+ inciso8);

        // 9. El área de un cuadrado cuya longitud de lado es a lo mucho 100 unidades.
        int areaCadrado = 100 * 100;
        System.out.println("\t 9. Área de un cuadrado:\t"+ areaCadrado);

        // 10. El valor de PI.
        final double ValorPi = Math.PI;
        System.out.println("\t 10. Valor de PI:\t\t"+ ValorPi);
    }
}
